CREATE VIEW v_conf_list AS
  SELECT
    `w`.`comment`                    AS `source_name`,
    `w`.`type`                       AS `job_type`,
    `w`.`region`                     AS `region`,
    `w`.`tid`                        AS `tid`,
    ifnull(`w`.`provinceId`, 100000) AS `province_id`,
    ifnull(`w`.`cityId`, 100000)     AS `city_id`,
    ifnull(`w`.`areaId`, 100000)     AS `area_id`,
    `s`.`id`                         AS `section_id`,
    `s`.`url`                        AS `url`,
    `s`.`comment`                    AS `section_type`,
    `s`.`keywordEncode`              AS `keywordencode`,
    `w`.`cookie`                     AS `cookie`,
    `cl`.`ajax`                      AS `ajax`,
    `cl`.`category`                  AS `category`,
    `cl`.`listdom`                   AS `listdom`,
    `cl`.`linedom`                   AS `linedom`,
    `cl`.`urldom`                    AS `urldom`,
    `cl`.`datedom`                   AS `datedom`,
    `cl`.`updatedom`                 AS `updatedom`,
    `cl`.`synopsisdom`               AS `synopsisdom`,
    `cl`.`authordom`                 AS `authordom`
  FROM ((`cw_info`.`conf_list` `cl` LEFT JOIN `cw_info`.`section` `s` ON ((`s`.`url` = `cl`.`url`))) LEFT JOIN
    `cw_info`.`website` `w` ON ((`w`.`id` = `s`.`site`)))
  WHERE (`w`.`status` = 'open');

