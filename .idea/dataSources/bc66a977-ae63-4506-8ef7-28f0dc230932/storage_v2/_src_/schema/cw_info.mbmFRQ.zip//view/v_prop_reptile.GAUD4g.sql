CREATE VIEW v_prop_reptile AS
  SELECT
    `pr`.`prop`    AS `prop`,
    `pr`.`reptile` AS `reptile`,
    `p`.`name`     AS `name`,
    `p`.`val`      AS `val`,
    `p`.`type`     AS `type`,
    `p`.`mark`     AS `mark`,
    `pr`.`usr`     AS `usr`,
    `pr`.`ctime`   AS `ctime`
  FROM (`cw_info`.`cw_prop_reptile` `pr` LEFT JOIN `cw_info`.`cw_prop` `p` ON ((`pr`.`prop` = `p`.`id`)));

